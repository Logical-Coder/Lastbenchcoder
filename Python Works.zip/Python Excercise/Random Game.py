import random
i=0
randint=random.randint(1,10)
while i<5:
    a=int(input("Enter number between 1 to 10:"))
    if randint==a:
        break
    elif i==4:
        print("Your 5 chance is over")
        i+=1
        break
    else:
        i+=1
        continue

if a==randint:
    print(" 'You Won' The Number is",randint)
else:
     print("Sorry The Number was",randint)

    
    