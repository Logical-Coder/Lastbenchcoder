armstrong=int(input("ENter Number"))
sum=0
temp=armstrong
length=len(str(armstrong))
while armstrong>0:
    digit=temp%10
    sum+=digit**length
    temp//=10
    
print(sum)
