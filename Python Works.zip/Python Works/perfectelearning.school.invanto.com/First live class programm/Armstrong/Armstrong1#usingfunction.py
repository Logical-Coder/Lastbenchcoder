#using function while loop
armstrong=int(input("Enter Armstrong Number:"))
length=len(str(armstrong))

def armstrongn(a):
    temp=armstrong
    sum=0
    while temp>=1:
            temp1=temp%10
            sum+=temp1**length
            temp//=10
    return sum

sum=armstrongn(armstrong)
if armstrong==sum:
        print(sum,"is Armstrong Number")
else:
        print(armstrong,"is not Armstrong Number")