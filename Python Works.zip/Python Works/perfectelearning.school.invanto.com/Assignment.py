file=open("file.txt")
inp=file.read()
for i in range(4):
    data=inp.find('@')
    findspace=inp.find(' ',data)
    print(inp[findspace+1:findspace+4].rstrip())
    
    