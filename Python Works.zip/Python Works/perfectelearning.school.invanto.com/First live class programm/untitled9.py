file=open("formatstr.txt")

for i in file:
    print(i.rstrip())