lss=[363,33,4465,585,554,55,23]
#find lowest value in list
e=lss[0]
for j in lss:
    if j<e:
        e=j
    else:
        j=e
print(e)
f=lss[0]
for j in range(0,len(lss)):
    if f<lss[j]:
        lss[j]=f
    else:
        f=lss[j]
print(f)
g=lss[0]
for j in lss:
    if g>j:
        g=j
    else:
        j=g
print(g)
h=lss[0]
for i in range(0,len(lss)):
    if h>lss[i]:
        h=lss[i]
    else:
        lss[i]=h
print(h)
    