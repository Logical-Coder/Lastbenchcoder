# -*- coding: utf-8 -*-
"""
Created on Sat Nov 14 17:37:15 2020

@author: Hacker
"""
count=0
string="Praveen how are you"
for i in range(0,len(string)):
    print(string[i])
    print(string[0:5:1])
    if string[i]=="e":
        count=count+1
print(count)