num=int(input("Enter Number:"))

if num>=0:
    if num==0:
        print("Its 0")
    else:
        print("its Positive Number")
else:
    print("Negative Number")
print("End")