num=int(input("Enter Number:"))

if num>1:
    print("Number is Greater than 1")
else:
    print("Number is Less than 1")