#Factorial number using while loop
print("H")

inp=int(input("Entre Fact Number"))
a=inp
b=inp-1
while b>=1:
    a*=b
    b-=1
print(a)

 
#Factorial Number using For Loop
inp=int(input("Enter Number"))
a=1
b=2
for i in range(1,inp):
    a*=b
    b+=1  
print(a)  
    
    
    



    
    

