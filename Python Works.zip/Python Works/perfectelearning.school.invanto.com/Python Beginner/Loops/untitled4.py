#While loop
a=list()
b="hello"
count=0
a.append(b)
while count>=0 and count<9:
    a.append(b)
    print(count,a[count])
    count+=1