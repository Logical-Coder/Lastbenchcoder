def armstrong(a):
    if a<1:
        return a
    else:
       return pow((a%10),b) + armstrong(a//10)

def factorial(a):
    sum=1
    if a>1:
        for i in range(1,a+1):
            sum*=i
        return sum    

def armstrong1(a):
    if a>1:
        return (a%10)**b + armstrong1(a//10)
    else:
        return a
        
        
    

inp=int(input("Enter input"))
b=len(str(inp))
s=armstrong(inp)
arm=armstrong1(inp)
f=factorial(inp)
print(s,f,arm)
