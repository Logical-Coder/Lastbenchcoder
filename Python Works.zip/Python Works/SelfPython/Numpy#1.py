import numpy as np

array_num=[[1,2,3,4],[5,6,7,8],[9,10,11,12],[13,14,15,16],[3,34,33,4]]

arry=np.array(array_num)
print(arry)
print(arry.shape)
a=int(len(arry)*len(arry[0])/2)
print(arry.reshape(2,a))
ary=np.arange(-10,10,1)
print(ary)
r_array1=np.random.randint(0,100,(10,5))
r_array2=np.random.randint(0,100,(10,5))
print(r_array1)
print(r_array2)
r_array3=r_array1+ r_array2
print(r_array1+ r_array2)
print("hshhshsh")
print(r_array3[0:5,0:2])