#Factorial
fact=int(input("Enter the Number for Factorial Output:"))
fact1=fact
fact2=fact
try:
    fact=int(fact)
    b=fact
    for i in range(1,fact):
        fact=fact-1
        b*=fact
           
except:
    print("Error, Enter Numaric input")
print("The Factorial Output is",b)




    