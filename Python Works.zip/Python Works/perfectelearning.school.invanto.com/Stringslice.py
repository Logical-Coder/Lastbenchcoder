# -*- coding: utf-8 -*-
"""
Created on Thu Nov 12 22:43:37 2020

@author: Hacker
"""

string=("Praveen Shridhar Acharya")
print(string[-len(str(string))::-1])
print(string[0:7])