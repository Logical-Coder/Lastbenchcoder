#using for loop
armstrong=int(input("Enter Armstrong Number:"))
length=len(str(armstrong))
temp=armstrong
sum=0
for i in range(0,length):
    temp1=temp%10
    sum+=temp1**length
    temp//=10
if armstrong==sum:
        print(sum,"is Armstrong Number")
else:
        print(armstrong,"is not Armstrong Number")
    
