#using While loop
armstrong=int(input("Enter Armstrong Number:"))
sum=0
length=len(str(armstrong))
temp=armstrong

while temp>=1:
    a=temp%10
    sum+=a**length
    temp//=10
if armstrong==sum:
        print(sum,"is Armstrong Number")
else:
        print(armstrong,"is not Armstrong Number")
        
