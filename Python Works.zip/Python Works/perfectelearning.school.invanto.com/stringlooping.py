# -*- coding: utf-8 -*-
"""
Created on Sat Nov 14 17:48:43 2020

@author: Hacker
"""
string="123456789"
for i in range(0,1):
    print(string[0:6:1])
    print(string[-1:-10:-1])
    print(string[0:9:4])
    print(string[0:9:3])
    print(string[0:9:2])
