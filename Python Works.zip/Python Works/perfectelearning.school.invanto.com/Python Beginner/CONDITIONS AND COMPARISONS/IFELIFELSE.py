dividend=int(input("Enter Dividend:"))
divisior=int(input("Enter Divider:"))

if dividend==0:
    print("Cannot divide by 0")
elif divisior==0:
    print("Cannot divide by 0")
else:
    print(dividend/divisior)