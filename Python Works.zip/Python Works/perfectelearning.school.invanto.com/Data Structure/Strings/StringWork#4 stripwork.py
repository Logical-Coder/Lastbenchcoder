name="     Praveenrightstrip"
name1="Praveenleftstrip  "
print("Before left Strip=",name)
print("After left strip=",name.lstrip())
print("Before right Strip=",name1)
print("After riht strinp=",name1.rstrip())
