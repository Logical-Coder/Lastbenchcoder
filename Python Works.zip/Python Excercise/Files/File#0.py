fl=open("text.txt")
cnt=dict()
lst=list()
st={}
ls=list()
count=0
sums=0
for i in fl:
    i.rstrip()
    ls.append(i.split())
for j in range(0,len(ls)):
    for k in ls[j]:
        lst.append(k)
for l in lst:
    cnt[l]=cnt.get(l,0)+1
for n,h in cnt.items():
    print(n,h)
    sums+=h
print(sums)