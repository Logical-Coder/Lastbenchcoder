lss=list()
l=0

while True:
    print("")
    print("S for Smallest Value")
    print("L for Largest Value")
    print("Press Enter to get the samllest and largest")
    inp=input("Enter Number:")
    try:
        inp=int(inp)
        lss.append(inp)
        s=lss[0]
        continue
    except:
        if inp=="l" or inp=="L":
            for j in lss:
                if j>l:
                    l=j
                else:
                    j=l
            print(lss)
            print("In this list The largest value in list:",j)
            continue
        if inp=="s" or inp=="S":
            for i in lss:
                if i<s:
                    s=i
                else:
                    i=s
            print(lss)
            print("In this The smallest value in list:",s)
            continue
        if inp=="" or inp.isalpha():
            print(lss)
            for k in range(0,len(lss)):
                if lss[0]<lss[k]:
                    lss[0]=lss[k]
            print("The Largest Value is",lss[0])
            for l in range(0,len(lss)):
                if lss[0]>lss[l]:
                    lss[0]=lss[l]
            print("The smallest Vlaue in list",lss[0])
            break
                    
                    
            
        
    
    
    
