#Factorial using list
fact=list()
fact1=input("Enter Factorial Number:")
for i in range(1,int(fact1)+1):
    fact.append(i)
print(fact)
sum=fact[0]
for j in range(0,len(fact)):
    sum*=fact[j]
print(sum)
