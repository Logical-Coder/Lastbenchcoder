armstrong=int(input("Enter Armstrong Number:"))
length=len(str(armstrong))
sum=0
temp=armstrong
while True:
    temp1=temp%10
    sum+=temp1**length
    temp//=10
    if temp<1:
        break
if armstrong==sum:
        print(sum,"is Armstrong Number")
else:
    print(armstrong,"is not Armstrong Number")
        