#ADD two number using default values
num1=15
num2=26
print("Addition of ",num1,"and",num2,"=",num1+num2)
print("Devision of ",num1,"and",num2,"=",num1/num2)
print("multiplication of ",num1,"and",num2,"=",num1*num2)
print("Subtraction of ",num1,"and",num2,"=",num1-num2)


#ADD two number taking input from user
num1=float(input("Enter first Number="))
num2=float(input("Enter Second Number="))

print("Addition of ",num1,"and",num2,"=",num1+num2)
print("Devision of ",num1,"and",num2,"=",num1/num2)
print("multiplication of ",num1,"and",num2,"=",num1*num2)
print("Subtraction of ",num1,"and",num2,"=",num1-num2)
