lst=["Rock","And","Roll",[1,233,44,[2,33,3],4,4],[23,33]]
print(lst)
lst[3][3][0]=58
print(lst)
print(len(str(lst[3][3][1])))
print(lst[3:5])