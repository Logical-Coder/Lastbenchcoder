alph="abcdefghijklmnopqrstuvwxyz"
a=alph.find("z")
for i in range(a,-1,-1):
    print(alph[i])