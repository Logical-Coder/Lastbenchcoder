# -*- coding: utf-8 -*-
"""
Created on Sun Nov  8 10:51:34 2020

@author: Hacker
"""

count=int(input("Enter how many times you want to print a below statement"))
cnt=0
while (cnt<count):
    count-=1
    print("hello")