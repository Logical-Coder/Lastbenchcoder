#Using WHile Loop
factwhile=int(input("Enter the Number for Factorial Output:"))
a=factwhile
b=factwhile-1
while b>=1:
    a*=b
    b-=1
    
print("The Factorial Output is",a)