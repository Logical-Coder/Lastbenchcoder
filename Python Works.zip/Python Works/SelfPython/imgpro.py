import cv2

source=cv2.VideoCapture(0)

while True:
    ret,img=source.read()
    if ret==False:
        break
    cv2.imshow('img',img)
    cv2.waitKey(10)
    if (Key==27):
        break
cv2.destroyAllWindows()