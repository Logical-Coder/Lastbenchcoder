from tkinter import *

root=Tk()
root.geometry('500x520+100+30')
root.resizable(0,0)
root.mainloop()