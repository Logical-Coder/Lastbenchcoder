file=open('file.txt')
for i in file:
    print(i.upper().rstrip())