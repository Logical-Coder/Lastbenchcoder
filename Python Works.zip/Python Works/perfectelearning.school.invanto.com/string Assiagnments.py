str = 'Perfect-Plan-B:0.7541'
datafind=str.find(':')
extract=str[datafind+1::]
print(type(extract))
cnvtfloat=float(extract)
print("Type of data",type(cnvtfloat),cnvtfloat)

