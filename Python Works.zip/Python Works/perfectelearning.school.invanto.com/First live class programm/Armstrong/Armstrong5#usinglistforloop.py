#usig list and forloop
armstr=list()
armstrong=input("Enter Armstrong Number:")
for i in armstrong:
   armstr.append(i)
sum=0  
for j in range(len(armstr)):
    temp=int(armstr[j])
    sum+=(pow(temp,len(armstr)))
if int(armstrong)==sum:
        print(sum,"is Armstrong Number")
else:
        print(armstrong,"is not Armstrong Number")