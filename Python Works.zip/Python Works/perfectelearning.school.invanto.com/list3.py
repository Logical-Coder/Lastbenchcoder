list=[2,3,3,3,2,34,4,1,45,56]


print(list.sort())

print(9 not in list)