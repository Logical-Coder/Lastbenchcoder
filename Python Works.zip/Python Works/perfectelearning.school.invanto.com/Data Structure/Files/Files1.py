fl=open('text.txt')
for i in fl:
    print(i)
