##Printing List
lists=[22,3,4,4,55,55,66,22]
countl=0
counts=0
count=0
k=0
s=None
total=0
for i in lists:
    print(count,i)
    count+=1
    
#finding largest number    
for i in (22,3,764,4,555,55,55,66,655):
    countl+=1
    if i>k:
        k=i
print("Largest Number is=",k)
print("Total Count is=",countl)
#finding smallest Number
for i in (22,3,764,4,555,55,55,66,655,5):
    if s is None:
        s=i
        
    elif i<s:
        s=i
        counts+=1
    

print("Smalles Number is",s)

#finding list total and average 
for i in lists:
    total+=i
print("Total of list",total)
print("Average of list",total/countl)

#Printing more than 20
for i in lists:
    if i>20:
        print(i)
    
    
    
    