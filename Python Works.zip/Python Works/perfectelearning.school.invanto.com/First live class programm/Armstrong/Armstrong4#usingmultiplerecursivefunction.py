#Armstrong using multiple recursive function 
armstrong=int(input("Enter Armstrong Number:"))
def armrecursive(armstrong):
    if armstrong<1:
        return armstrong
    else:
        return (armstrong%10)**length + armrecursive(armstrong//10)
    

def armrecursive1(armstrong):
    if armstrong<1:
        return armstrong
    else:
        temp=armstrong%10
        return temp**length + armrecursive1(armstrong//10)
    
def armrecursive2(armstrong):
    if armstrong>1:
        return pow((armstrong%10),length) + armrecursive2(armstrong//10)
    else:
        return armstrong
    

length=len(str(armstrong))
sum=armrecursive(armstrong)
sum1=armrecursive1(armstrong)
sum2=armrecursive2(armstrong)
if armstrong==sum and armstrong==sum1 and armstrong==sum2:
        print(sum,"is Armstrong Number")
else:
        print(armstrong,"is not Armstrong Number")
