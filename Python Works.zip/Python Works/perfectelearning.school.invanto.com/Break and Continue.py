# -*- coding: utf-8 -*-
"""
Created on Sun Nov  8 12:17:36 2020

@author: Hacker
"""

while True:
    inp=input("Enter Your Name")
    if inp[0]=="#":
        print("DOnt ENter #")
        continue
    if inp=="Praveen":
        break
    print(inp)
print(inp,"Done")

            
        