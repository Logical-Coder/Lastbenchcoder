num = int(input("Enter Sequence of Number: "))
def fibonocci(n1,n2):
    return n1+n2

n=0
n1=0
n2=1
for i in range(0,num):
    n=fibonocci(n1, n2)
    print(n)
    n1=n2
    n2=n
    


