inp=int(input("Enter Number"))

sum=0
temp=inp
lent=len(str(inp))

while temp>=1:
    a=temp%10
    sum+=a**lent
    temp//=10
print(sum)
    