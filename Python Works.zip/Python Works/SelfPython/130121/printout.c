print("Hello Wolrd!")
str="this is variable stores the string"
print(str)