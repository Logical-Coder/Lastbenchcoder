#Factorial using Infinite Loop
fact=int(input("ENter Number:"))
fact1=fact-1
while True:
    fact=fact*fact1
    fact1-=1
    if fact1<2:# if fact1==1 or if fact1<=1
        break
print("The Factorial Output is",fact)
#Praveen Acharya