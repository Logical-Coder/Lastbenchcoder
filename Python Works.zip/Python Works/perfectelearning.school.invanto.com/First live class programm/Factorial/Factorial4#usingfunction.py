#Factorial using function
def factorial(a,b):
    while True:
        a*=b
        b-=1
        if b<2:
            break
    return a
fact=input("Enter Factorial Number:")
try:
    fact=int(fact)
    fact1=fact-1
except:
    print("Error")
sum=factorial(fact,fact1)
print("The Factorial Output is",sum)