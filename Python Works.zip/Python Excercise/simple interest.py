princamount=int(input("Enter Amount:"))
timeinp=int(input("Enter time in units:"))
rateinp=int(input("Enter rate of intrest in %:"))

print((princamount*timeinp*rateinp)/100)
print(princamount*(1+rateinp/100)*timeinp)