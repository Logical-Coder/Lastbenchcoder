stuff=list()
while True:
    inp=input("ENter Number:")
    if inp =="done":break
    value=float(inp)
    stuff.append(value)
average=sum(stuff)/len(stuff)
print(average)

stuff=list()
while True:
    inp=input("ENter Number:")
    if inp =="done":break
    value=float(inp)
    stuff.append(value)
average=sum(stuff)/len(stuff)
print(average)       