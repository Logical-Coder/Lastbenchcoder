import math
fact=int(input("Enter Factorial Number"))
print(math.factorial(fact))