age=int(input("Enter your age:"))
yearremaining=60-age
daysremaining=yearremaining*365
weekssremaining=yearremaining*52
mothsremainint=yearremaining*12

print(daysremaining+15,weekssremaining,mothsremainint)