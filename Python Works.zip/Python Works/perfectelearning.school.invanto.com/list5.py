list=[]
list.append("34")
list.append("26")
list.append("25")

print(list)

print("25" not in list)


