ppb = ('p','y','t','h','o','n') 
print(ppb[1:3])