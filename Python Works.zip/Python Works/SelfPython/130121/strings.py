print("The head \n The story is here")
print("Praveen"+" Acharya")
a=("Praveen"+"Acharya")
print(a[::-1])