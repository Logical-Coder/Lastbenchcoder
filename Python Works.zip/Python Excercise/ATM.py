
print("For Adding user press    1")
print("For Removing user press  2")
print("For Deposite Money Press 3")
print("For WithDraw Money Press 4")
print("")
print("")
print("")
users=[]
userscard=[]
userspassword=[]
usersdepositamount=[]
usersaction=str(input("Enter:"))
action=str(input("Enter to continue:"))



"""if usersaction=="2":

if usersaction=="3":
  
if usersaction=="4":
"""
    
while usersaction!="exit":    
    if usersaction=="1":
        while True:
            username=input("Enter Your Name:")
            try:
                username=int(username)
                print("Error Enter Correct Name")
                continue
            except:
                users.append(username)
                break
        while True:
                usercard=input("Enter Your 16 Digit card Number")
                try:
                    usercard=int(usercard)
                    cardlength=len(str(usercard))
                    if cardlength!=16:
                        print("Enter 16 Digits Only")
                        continue
                    else:
                        userscard.append(usercard)
                    break
                        
                except:
                    print("Enter Correct Numaric Value")
        while True:
            userspswd=input("Enter 4 Digit Pin:")
            try:
                userspswd=int(userspswd)
                lengthpsd=len(str(userspswd))
                if lengthpsd==4:
                    userspassword.append(str(userspswd))
                    usersaction=str(input("Adding user Press 1 withdraw press 4 \n Deposite Cash Press 3, Remove user press 2:type exit to exit:"))

                else:
                    print("Enter 4 Digit PIN Only")
                    continue
            except:
                print("Exiting")
            break
                    



    if usersaction=="4":
        withdrawmoney=input("Enter WithDraw Money min:100 max 30K:")
        if withdrawmoney.isnumeric():
            confirmwithdrawamount=str(input("Enter Y or N"))
            if confirmwithdrawamount=="Y":
               if int(withdrawmoney)>=100 and int(withdrawmoney)<=30000:
                usercard=input("Enter Your 16 DIGIT Card Number:")
                userspswd=input("Enter 4 Digit Pin:")
                usercard=int(usercard)
                cardlength=len(str(usercard))
                if cardlength!=16:
                    print("Enter 16 Digits Only")
                else:
                    confirmcard=userscard.index(usercard)
                    confirmpin=userspassword.index(userspswd)
                    if usercard==userscard[confirmcard] and userspswd==userspassword[confirmpin]:
                        print("cardholder=",users[confirmcard],withdrawmoney,"withdraw successfully done")
                        usersaction=str(input("Adding user Press 1 withdraw press 4 \n Deposite Cash Press 3, Remove user press 2:type exit to exit:"))

        else:
            print("DO not Enter alphabets")
            
        
        
            

        
    
                            
                            
        
        
    

def depositmoney():
    print("Deposit Money")