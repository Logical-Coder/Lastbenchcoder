list =[23,3,35,53,4,44,4,4,44,4,44]
sum1=0
for i in range(len(list)):
    sum1+=list[i]

print(sum1)
sum2=0
for li in list:
    sum2+=li

print(sum2)