Lst=[]
count=1
def convert(ls,a,c):
    string=""
    for i in ls:
        string+=i
    print(string)
    
while True:
    print("Enter Your ",count," Charecter")
    inp=str(input("Enter:"))
    if len(inp)<2:
        Lst.append(inp)
        count+=1
        continue
    elif inp=="exit" or inp=="Exit":
        convert(Lst,5,count)
        break
    elif len(inp)>1:
        print("Enter One Charecter Only")
        continue


