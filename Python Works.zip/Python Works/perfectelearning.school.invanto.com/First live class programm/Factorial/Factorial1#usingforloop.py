#using for loop
factfor=int(input("Enter the Number for Factorial Output:"))
a=1
b=2
for i in range(1,int(factfor)):
    a*=b
    b+=1
print("The Factorial Output is",a)