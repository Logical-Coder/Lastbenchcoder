# -*- coding: utf-8 -*-
"""
Created on Sat Nov 14 18:27:13 2020

@author: Hacker
"""

string="    Praveen How are you    "

a= 'How' and 'Praveen' in string
print(a)
print(string.islower())
print(string.isupper())
string=string.upper()
print(string)
print(string.isupper())
string=string.lower()
print(string)
print(string.islower())
print(string.upper())
print(string.strip())