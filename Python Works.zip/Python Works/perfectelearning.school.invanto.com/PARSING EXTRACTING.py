# -*- coding: utf-8 -*-
"""
Created on Sat Nov 14 18:53:38 2020

@author: Hacker
"""

data="From praveenachari45@gmail.com july 5 1994"

atfind=data.find("p")
spcfind=data.find('@',atfind)
print(atfind)
print(spcfind,data[spcfind-1],data[spcfind+1])
print(data[atfind:spcfind])


for let in 'praveen':
    print(let)