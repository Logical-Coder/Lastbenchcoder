inp=int(input("Enter Factorial Number"))
num1=inp
num2=inp-1

while num2>=1:
    num1*=num2
    num2-=1
print(num1)


inp1=int(input("Enter Factorial Number"))
a=1
b=2
for i in range(1,inp1):
    a*=b
    b+=1
print(a)

inp2=input("Enter Armstrong input:")

temp=int(inp2)
length=len(inp2)
sum=0
while temp>=1:
    temp1=temp%10
    sum+=temp1**length
    temp//=10
print(sum)

    
    
    
    
    

    