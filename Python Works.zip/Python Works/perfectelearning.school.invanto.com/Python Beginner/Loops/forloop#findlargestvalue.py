lss=[363,33,4465,585,554,55,23]
#find largest value in list
a=0
for i in lss:
    if i>a:
        a=i 
    else:
        i=a
print(a)
b=0
for i in range(0,len(lss)):
    if lss[i]>b:
        b=lss[i]
    else:
        lss[i]=b
print(b)
c=0
for i in lss:
    if c<i:
        c=i
    else:
        i=c
print(c)
d=0
for i in range(0,len(lss)):
    if d<lss[i]:
        d=lss[i]
    else:
        lss[i]=d
print(d)
    