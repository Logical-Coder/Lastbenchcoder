#Simple intrest 
amount=float(input("Enter amount:"))
time=int(input("Enter time:"))
rate=float(input("Enter intrest rate:"))

si=(amount*time*rate)/100
print(si)

#compound intrest
ci=amount*(1+(rate/100))*time
print(ci)