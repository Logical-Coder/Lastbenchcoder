#function
def add(a,b):
    sum=a+b
    return sum
def multiply(a,b):
    sum=a*b
    return sum
def devide(a,b):
    sum=a/b
    return sum
def substract(a,b):
    sum=a-b
    return sum
airthmatic=list("")
airth=["add","multiply","devide","substract"]
inp1=float(input("Enter first number"))
inp2=float(input("Enter Second Number"))
for i in range(0,len(airth)):
        if airth[i]=="add":
            a=add(inp1,inp2)
        elif airth[i]=="multiply":
            m=multiply(inp1,inp2)
        elif airth[i]=="devide":
            d=devide(inp1,inp2)
        elif airth[i]=="substract":
            s=substract(inp1,inp2)
            
print(a,m,d,s)