# -*- coding: utf-8 -*-
"""
Created on Sun Nov 15 17:19:10 2020

@author: Hacker
"""
count=0
text=open("New Text Document.txt")
for i in text:
    print(i)
    count=count+1
    print(count)