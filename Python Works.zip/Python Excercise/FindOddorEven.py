#find odd or Even
number=int(input("Enter:"))

if number%2==0:
    print(number,"Even")
else:
   print(number,"odd")