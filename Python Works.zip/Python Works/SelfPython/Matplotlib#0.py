import matplotlib.pyplot as plt
import numpy as np

a=np.arange(0,100,3)
x=([1,2,3,4,5,6,7])
y=([45,67,88,66,66,55,54])
y1=2*a+3
y2=np.power(a,2)
plt.plot(a,y1,'r--')
plt.plot(a,y2,'g*')
print(a)
print(y1)
plt.ylabel("Numbers")
plt.show()