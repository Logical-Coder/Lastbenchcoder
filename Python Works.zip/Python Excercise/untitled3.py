    print("For Adding user press    1")
    print("For Removing user press  2")
    print("For Deposite Money Press 3")
    print("For WithDraw Money Press 4")
    print("")
    print("")
    print("")
    users=[]
    userscard=[]
    userspassword=[]
    users=users.append(a)
    userscard=userscard.append(b)
    userspassword=userspassword.append(c)
    usersaction=str(input("Enter:"))
    if usersaction=="1":
        addinguser()
   

def addinguser():
    while True:
            username=str(input("Enter Your Name:"))
            try:
                username=int(username)
                print("Error, Enter the name correctly")
                continue
            except:
                users.append(username)
                while True:
                    usercard=int(input("Enter Your 16 Digit Card Number:"))
                    try:
                        usercard=int(usercard)
                        cardlength=len(str(usercard))
                        if cardlength!=1:
                            print("Error, Enter correct 16 Digits Number")
                            continue
                        else:
                            userscard.append(usercard)
                            print(userscard,username)
                            break
                        
                    except:
                        print("Error, Enter Numaric Value")

