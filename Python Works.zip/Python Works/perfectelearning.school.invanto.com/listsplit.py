string="Who.are.You"
print(string.split("."))