# -*- coding: utf-8 -*-
"""
Created on Sun Nov  8 17:59:26 2020

@author: Hacker
"""

n=50
while n>0:
    print(n)

    print('All DOne')