import cv2
img=cv2.imread(r'D:\IMG_20191225_143618.jpg')
img2=cv2.imread(r'D:\IMG_20191225_143618.jpg')
img3=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
img4=cv2.imread(r'D:\IMG_20191225_143618.jpg')
#cv2.rectangle(img,(70,100),(110,130),(0,0,0),2)
#cv2.rectangle(img,(180,100),(140,130),(0,0,0),2)
#img[100:130,60:200]=[187, 145, 255]
#print(img.shape)
for j in range(0,297):
    for i in range(0,292):
        if i%2==0:
            img2[j,i]=[89,255,255]
        else:
            continue
for j in range(0,297):
    for i in range(0,292):
        if i%2==0:
            img4[j,i]=[0,0,0]
        else:
            continue

cv2.imshow('LIVE',img)
cv2.imshow('LIVE1',img2)
cv2.imshow('LIVE2',img3)
cv2.imshow('LIVE3',img4)
cv2.waitKey(0)
cv2.destroyAllWindows()
