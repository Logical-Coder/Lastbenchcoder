#Factorial Using recursion
def factr(n):
    if n<2:
        return 1
    else:
        print(n)
        return n*factr(n-1)
    
fact=int(input("Enter the Number for Factorial Output:"))
result=factr(fact)
print(result)