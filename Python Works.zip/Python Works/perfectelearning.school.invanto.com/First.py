days=input("Enter  days=")
rate=input("Enter  rate=")
try:
    a=float(days)
    b=float(rate)
    
except:
    print("Error, please enter numeric input")
    
#another program with numaric output
days=input("Enter days=")
rate=input("Enter rate=")
try:
    a=float(days)
    b=float(rate)
    print("Conversion is Successfull",a*b)
except:
    print("Error, please enter numeric input")

#another program with out numaric output
days=input("Enter  days=")
rate=input("Enter  rate=")
try:
    a=float(days)*float(rate)
except:
    print("Error, please enter numeric input") 
    
    
    
    


