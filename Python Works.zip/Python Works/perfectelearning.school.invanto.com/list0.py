names=["Praveen","Jyoti","Krupa",6665,[272882,383883,3883,4,3455]]

names[4][2]=88887
print(names,len(names))