stuff=list()
stuff.append("Hello")
stuff.append("Jow")
print(stuff)
