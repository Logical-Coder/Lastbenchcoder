a=int(input("Enter the terms"))
f=0
s=1
print(f,s,end=" ")
for x in range(2,a):
        next=f+s                           
        print(next,end=" ")
        f=s
        s=next