#Armstrong Using For loop
numb=int(input("Enter :"))
armnum=numb
n=len(str(numb))
count=n
x=0
for i in range(n):
    a=numb%10
    x+=a**n
    numb=numb//10

if x==armnum:
        print(x,"is armstrong Number")
else:
        print(x,"is not armstrong Number")
    

      

        
        


        
    
    


