# -*- coding: utf-8 -*-
"""
Created on Sat Nov 21 11:37:28 2020

@author: Hacker
"""

print(1 + 3 * 2 - 8 / 4)