#ADD two number taking input from user
num1=input("Enter first Number=")
num2=input("Enter Second Number=")
sum=float(num1)+float(num2)
print("The Sum of {0:^5} and {1:^5} is{2:<5}".format(num1,num2,sum))

