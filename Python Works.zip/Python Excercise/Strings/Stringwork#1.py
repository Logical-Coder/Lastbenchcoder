string="abcdefghijklmnopqrstuvwxyz"
count=1
def convetlist(a):
    lst.append(a)

lst=list()
for i in string:
    print(i.upper(),i.capitalize(),i.casefold())
    convetlist(i.upper())
print(lst)