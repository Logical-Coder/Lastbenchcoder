# using using while loop

num=int(input("ENter Number"))
sum=0
temp=num
length=len(str(num))

while temp>0:
    digit=temp%10
    sum+=digit**length
    temp//=10
if sum==num:
    print(sum,"is Arm strong number")
else:
    print(sum,"is not armstrong number")
