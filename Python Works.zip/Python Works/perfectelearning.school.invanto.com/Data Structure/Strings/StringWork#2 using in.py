while True:
    inp=str(input("Enter Praveen"))
    if "praveen" in inp:
        print("Its Praveen")
        break
        
    elif "Praveen" in inp:
        print("Its Praveen")
        break

    else:
        continue


