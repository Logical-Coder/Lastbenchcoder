# -*- coding: utf-8 -*-
"""
Created on Thu Nov 12 22:29:40 2020

@author: Hacker
"""

string=str(input("Enter The Sting"))

for i in range(0,len(string)):
    
    print(string[i])
    