print("Hello World")

string="Hello Wolrld"

for i in string:
    print(i,i,i,i,i)