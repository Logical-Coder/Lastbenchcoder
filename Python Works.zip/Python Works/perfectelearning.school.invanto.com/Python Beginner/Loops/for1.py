l=["Welcome","Praveen","This","Python"]
for i in [5,4,3,2,1]:
    print(i)

for i in range(0,len(l)):
    print(l[i])